# gas tank yolo dataset > 2022-06-29 8:05am
https://universe.roboflow.com/zxc-lgbhl/gas-tank-yolo-dataset

Provided by a Roboflow user
License: CC BY 4.0

