This notebook has been tested in an anaconda environment on windows with python 3.11.9 installed.

It should run as well on Linux and or with other versions of python as long as the correct packages have been installed. 

To run the notebook, jupyter needs to be installed in your environment. (pip install jupyter)

To run this notebook in anaconda (but feel free to use an other env mngr)
  activate 'your_env' 
  cd 'path_to_where you unzipped the sources'
  jupyter notebook

